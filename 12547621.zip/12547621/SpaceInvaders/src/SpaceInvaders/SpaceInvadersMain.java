package SpaceInvaders;

import javafx.application.Application;

/**
 * Criação da classe main do projeto
 * @author pedro
 */
public class SpaceInvadersMain{
    public static void main(String[] args){
        Application.launch(args);
    }
}